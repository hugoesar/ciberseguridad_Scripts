﻿#intrgrantes: Angel Esau Hernandez Garcia, Kevin Rafael Ochoa López, Hugo Gael Arredondo Esparza
Get-Service | Select-Object Name, DisplayName, Status, StartType | ConvertTo-Json
